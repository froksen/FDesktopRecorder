<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_CH" sourcelanguage="da">
<context>
    <name>AboutProg</name>
    <message>
        <location filename="../aboutprog.ui" line="14"/>
        <source>About kTffmpeqQt</source>
        <translation>Über kTffmpeqQt</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="48"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="63"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2 - &lt;a href=&quot;http://www.gnu.org/licenses/gpl-2.0.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/gpl-2.0.html&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nickname: Froksen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Navn: Ole Holm Frandsen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Based on:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A ffmpeq script by Peter Lybeth from the danish GNU/Linux show &amp;quot;Kanal Tux&amp;quot;: &lt;a href=&quot;http://www.kanaltux.dk&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.kanaltux.dk&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licenz: &lt;/span&gt;GPLv2 - &lt;a href=&quot;http://www.gnu.org/licenses/gpl-2.0.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/gpl-2.0.html&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Geschrieben von:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nickname: Froksen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Name: Ole Holm Frandsen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Basierend auf:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Dem ffmpeq script von Peter Lybeth vom Dänischen GNU/Linux  &amp;quot;Kanal Tux&amp;quot;: &lt;a href=&quot;http://www.kanaltux.dk&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.kanaltux.dk&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="82"/>
        <source>Translations</source>
        <translation>Übersetzungen</translation>
    </message>
    <message utf8="true">
        <location filename="../aboutprog.ui" line="88"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;FDesktopRecorder have been translated into some languages. If you want to translate it into your language you can contact me on opendesktop.org by sending me a message.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Translated by&lt;/span&gt;:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Danish - Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;German - Chris &amp;quot;&lt;span style=&quot; font-family:&apos;arial,sans-serif&apos;; color:#222222; background-color:#ffffff;&quot;&gt;saftsocken&amp;quot; Räss&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;FDesktopRecorder wurde in folgenden Sprachen übersetzt. Wenn Du helfen willst und dieses Programm in deine Sprache übersetztn willst, kontaktiere mich auf: opendesktop.org&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Übersetzt von&lt;/span&gt;:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Danisch - Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Deutsch - Chris &amp;quot;&lt;span style=&quot; font-family:&apos;arial,sans-serif&apos;; color:#222222; background-color:#ffffff;&quot;&gt;saftsocken&amp;quot; Räss&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="107"/>
        <source>OK</source>
        <translation>Fertig</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="34"/>
        <source>About FDesktopRecorder</source>
        <translation>Über: FDesktopRecorder</translation>
    </message>
</context>
<context>
    <name>ApplicationSettings</name>
    <message>
        <source>Startup Behavior</source>
        <translation type="obsolete">Opstartshåndtering</translation>
    </message>
    <message>
        <source>If checked the application will start with a hidden main window.</source>
        <translation type="obsolete">Hvis afkrydset vil programmet starte med skjult hoved vindue.</translation>
    </message>
    <message>
        <source>Start with hidden window</source>
        <translation type="obsolete">Start med skjult hovedvindue</translation>
    </message>
</context>
<context>
    <name>ConfigurationFile</name>
    <message>
        <location filename="../configurationfile.cpp" line="74"/>
        <source>recording</source>
        <translation type="unfinished">Aufnahme</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="20"/>
        <source>FDesktopRecorder</source>
        <translation>FDesktopRecorder</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <source>When the recording starts, it will record your entire desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Records your entire desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="55"/>
        <source>When you start the recording, you will have to choose the window that you want to record</source>
        <extracomment>dsfdsfds</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <source>Record a single window or screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="71"/>
        <source>Start a recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="74"/>
        <source>Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="97"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="104"/>
        <source>If checked, it will record no audio from the microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="107"/>
        <source>Mute the microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="110"/>
        <source>Mute microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="179"/>
        <source>Shows information about this program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="190"/>
        <source>Let you change an amount of different settings like recording framerate etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Shows a console where you can see the output. Usefull if recording fails.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="204"/>
        <source>Show/Hide console output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Open recording directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <location filename="../mainwindow.ui" line="215"/>
        <source>Open directory containing your recordings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="198"/>
        <source>Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record screen</source>
        <translation type="obsolete">Aufnahmefenster</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Durchsuchen</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation type="obsolete">Ordnername</translation>
    </message>
    <message>
        <source>Specify the location where you want to save the recorded file</source>
        <translation type="obsolete">Spezifiziere den Speicherort der Ausgabe</translation>
    </message>
    <message>
        <source>Recording</source>
        <translation type="obsolete">Aufnahme</translation>
    </message>
    <message>
        <source>Lets you choose where the recorded file should be saved</source>
        <translation type="obsolete">Läss dich wählen wo die Aufnahme gespeichert werden soll</translation>
    </message>
    <message>
        <source>Gennemse..</source>
        <translation type="obsolete">Blättern</translation>
    </message>
    <message>
        <source>Pixmap</source>
        <translation type="obsolete">Pixmap</translation>
    </message>
    <message>
        <source>File exists. If you continue it will be overwritten</source>
        <translation type="obsolete">Datei existiert bereits. Beim weiterfahren wird die alte Datei überschrieben</translation>
    </message>
    <message>
        <source>Fileformat</source>
        <translation type="obsolete">Fileformat</translation>
    </message>
    <message>
        <source>Choose the fileformat for the recording</source>
        <translation type="obsolete">Wahl des Formates</translation>
    </message>
    <message>
        <source>Recording area</source>
        <translation type="obsolete">Aufnahme</translation>
    </message>
    <message>
        <source>Sets the recording area to a single window</source>
        <translation type="obsolete">Vergrössert das Aufnahmefenster</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="61"/>
        <source>Single Window</source>
        <translation type="unfinished">Einzelfenster</translation>
    </message>
    <message>
        <source>Sets the recording area to a custom size</source>
        <translation type="obsolete">Vergrössert die Aufnahmeeinstellungen</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="obsolete">Eigene Einstellungen</translation>
    </message>
    <message>
        <source>Sets the recording area to the entire screen</source>
        <translation type="obsolete">Vergrössert das Programm auf Vollbild</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="42"/>
        <source>Entire screen</source>
        <translation>Vorheriger Bildschirm</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">Breite</translation>
    </message>
    <message>
        <source>Set width</source>
        <translation type="obsolete">Setze Breite</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="obsolete">Höhe</translation>
    </message>
    <message>
        <source>Set height</source>
        <translation type="obsolete">Setze Höhe</translation>
    </message>
    <message>
        <source>Microfone</source>
        <translation type="obsolete">Mikrofon</translation>
    </message>
    <message>
        <source>Choose an audioinput from which the sound should be recorded</source>
        <translation type="obsolete">Tonaufnahme Gerät</translation>
    </message>
    <message>
        <source>If checked no audio will be recorded</source>
        <translation type="obsolete">Wenn ausgewählt wird kein Audio aufgenommen</translation>
    </message>
    <message>
        <source>Record no sound</source>
        <translation type="obsolete">Aufnahme kein Ton</translation>
    </message>
    <message>
        <source>Delay start a number of seconds</source>
        <translation type="obsolete">Verzögerung in Sekunden</translation>
    </message>
    <message>
        <source>Delay start </source>
        <translation type="obsolete">Udskud start</translation>
    </message>
    <message>
        <source>Delay the start by a number of seconds...</source>
        <translation type="obsolete">Verzögerung starten mit einer anzahl Sekunden...</translation>
    </message>
    <message>
        <source>Start the recording</source>
        <translation type="obsolete">Start der Aufnahme</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="37"/>
        <source>Start recording</source>
        <translation>Beginn Aufnahme</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="94"/>
        <source>Stop the recording</source>
        <translation type="unfinished">Beende die Aufnahme</translation>
    </message>
    <message>
        <source>Stop recording</source>
        <translation type="obsolete">Beende die Aufnahme</translation>
    </message>
    <message>
        <source>Quits the program</source>
        <translation type="obsolete">Beendet das. Programm</translation>
    </message>
    <message>
        <source>Quit Program</source>
        <translation type="obsolete">Schliesse Programm</translation>
    </message>
    <message>
        <source>The main window will be minimized to systemtray</source>
        <translation type="obsolete">Das Hauptfenster wird in die Taskleiste minimiert</translation>
    </message>
    <message>
        <source>Minimize to tray</source>
        <translation type="obsolete">Minimieren</translation>
    </message>
    <message>
        <source>Shows the terminalouput if the ffmpeq script</source>
        <translation type="obsolete">Zeigt Terminaloutput vom ffmpeq Script</translation>
    </message>
    <message>
        <source>Show terminal output</source>
        <translation type="obsolete">Zeige Terminal Ausgabe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="176"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Bearbeiten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>About FDesktopRecorder</source>
        <translation type="unfinished">Über FDesktopRecorder</translation>
    </message>
    <message>
        <source>Application Settings</source>
        <translation type="obsolete">Program indstillinger</translation>
    </message>
    <message>
        <source>About kTffmpeqQt</source>
        <translation type="obsolete">Om kTffmpeqQt</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="obsolete">Über Qt</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="187"/>
        <location filename="../mainwindow.ui" line="193"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="39"/>
        <source>Minimize and start record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="191"/>
        <source>Recording started</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="198"/>
        <source>Please wait while saving the recording. Might take some time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="206"/>
        <source>Successfully finished recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="214"/>
        <location filename="../mainwindow.cpp" line="285"/>
        <source>Latest Recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="219"/>
        <source>Failed to recording!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="220"/>
        <source>Failed to start recording!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="221"/>
        <source>Press &apos;show details&apos; to see console ouput.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="273"/>
        <source>&amp;Show/Hide window</source>
        <translation>&amp;Zeige/Verstecke Fenster</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="276"/>
        <source>&amp;Stop recording</source>
        <translation>&amp;Beende die Aufnahme</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="279"/>
        <source>&amp;Latest recording: </source>
        <translation>&amp;Letzte Aufnahme:</translation>
    </message>
    <message>
        <source>Latest recording: </source>
        <translation type="obsolete">Letzte Aufnahme: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="287"/>
        <source>&amp;Quit program</source>
        <translation>&amp;Schliesse Programm</translation>
    </message>
    <message>
        <source>recording</source>
        <translation type="obsolete">Aufnahme</translation>
    </message>
    <message>
        <source>Start recording and minimize</source>
        <translation type="obsolete">Beginn in minimierter Ansicht</translation>
    </message>
    <message>
        <source>Script saved: </source>
        <translation type="obsolete">Script er gemt: </translation>
    </message>
    <message>
        <source>Sure that you want to start a recording in </source>
        <translation type="obsolete">Bist du sicher dass du die Aufnahme starten willst in </translation>
    </message>
    <message>
        <source>Sure that you want to start a recording?</source>
        <translation type="obsolete">Bist du sicher dass du die Aufnahme starten willst?</translation>
    </message>
    <message>
        <source>Press &apos;show details&apos; for information about the script. USE AT OWN RISK</source>
        <translation type="obsolete">Drücke &apos;Details&apos; für mehr Informationen über das Skript . NUTZEN AUF EIGENE GEFAHR</translation>
    </message>
    <message>
        <source>Recording starts in </source>
        <translation type="obsolete">Aufnahme startet in </translation>
    </message>
    <message>
        <source> sekunder</source>
        <translation type="obsolete"> zweiter</translation>
    </message>
    <message>
        <source>Recording not yet startet but when the icon changes, the recording starts.</source>
        <translation type="obsolete">Aufnahme wird erst beim wechsel des Icons begonnen.</translation>
    </message>
    <message>
        <source>No recording started</source>
        <translation type="obsolete">Keine Aufnahme gestartet</translation>
    </message>
    <message>
        <source>The program did not start any recording</source>
        <translation type="obsolete">Das Programm hat keine Aufnahme gestartet</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Speichern</translation>
    </message>
    <message>
        <source>Movies (*.mkv *.avi)</source>
        <oldsource>Film (*.mkv *.avi)</oldsource>
        <translation type="obsolete">Filme (*.mkv *.avi)</translation>
    </message>
    <message>
        <source>Movies (*.mkv *.avi *.ogg *.mpeg *.flv *.wmv *.mov)</source>
        <translation type="obsolete">Filme (*.mkv *.avi *.ogg *.mpeg *.flv *.wmv *.mov)</translation>
    </message>
    <message>
        <source>Window hidden</source>
        <translation type="obsolete">Fenster verborgen</translation>
    </message>
    <message>
        <source>The programs continues to run in systemtray. Right-click the icon for more options</source>
        <translation type="obsolete">Das Programm setzt die Arbeit in der Taskliste fort. Rechtsklick auf das icon für mehr Informationen</translation>
    </message>
    <message>
        <source>INFORMATION: Delayed start stoppet!</source>
        <translation type="obsolete">INFORMATION: Verzögerter start gestoppt!</translation>
    </message>
    <message>
        <source>Delayed start stoppet!</source>
        <translation type="obsolete">Verzögerter Start und Stop!</translation>
    </message>
    <message>
        <source>The delayed start was stopped and therefore no recording will start</source>
        <translation type="obsolete">Der verzögerte Start wurde beendet und es wurde keine Aufnahme gestartet</translation>
    </message>
    <message>
        <source>Error: Recording failed!</source>
        <translation type="obsolete">Error: Aufnahmefehler!</translation>
    </message>
    <message>
        <source>Press &apos;show terminal output&apos; for details</source>
        <translation type="obsolete">Drücke &apos;zeige Terminal Output&apos; für Details</translation>
    </message>
    <message>
        <source>INFORMATION: Recording stopped</source>
        <translation type="obsolete">INFORMATION: Aufnahme gestopt</translation>
    </message>
    <message>
        <source>Recording finished</source>
        <translation type="obsolete">Aufnahme beendet</translation>
    </message>
    <message>
        <source>The program finished recording</source>
        <translation type="obsolete">Das Programm hat die Aufnahme beendet</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Einstellungen</translation>
    </message>
    <message>
        <source>Record Settings (ffmpeg)</source>
        <translation type="obsolete">Aufnahmeeinstellungen (ffmpeg)</translation>
    </message>
    <message>
        <source>Record Settings</source>
        <translation type="obsolete">Aufnahmeeinstellungen</translation>
    </message>
    <message>
        <source>Frames pr. sec</source>
        <translation type="obsolete">Bilder pro Sek</translation>
    </message>
    <message>
        <source>Video codec</source>
        <translation type="obsolete">Video-Codec</translation>
    </message>
    <message>
        <source>Auto detect</source>
        <translation type="obsolete">Auto-Auswahl</translation>
    </message>
    <message>
        <source>Sound codec</source>
        <translation type="obsolete">Audio-Codec</translation>
    </message>
    <message>
        <source>Audiochannels</source>
        <translation type="obsolete">Audio-Kanal</translation>
    </message>
    <message>
        <source>Restore to default</source>
        <translation type="obsolete">Standart wiederherstellen</translation>
    </message>
    <message>
        <source>Startup Behavior</source>
        <translation type="obsolete">Startverhalten</translation>
    </message>
    <message>
        <source>If checked the application will start with a hidden main window.</source>
        <translation type="obsolete">Wenn ausgewählt wird das Programm versteckt starten</translation>
    </message>
    <message>
        <source>Start with hidden window *</source>
        <translation type="obsolete">Start mir verstecktem Fenster</translation>
    </message>
    <message>
        <source>recording</source>
        <translation type="obsolete">Aufnahme</translation>
    </message>
    <message>
        <source>Default filename *</source>
        <translation type="obsolete">Standart Dateiname *</translation>
    </message>
    <message>
        <source>Default fileformat *</source>
        <translation type="obsolete">Standart Dateiformat *</translation>
    </message>
    <message>
        <source>Default record device *</source>
        <translation type="obsolete">Standart Aufnamegerät * </translation>
    </message>
    <message>
        <source>* Will first take effect after a restart of this program</source>
        <translation type="obsolete">* Wird erst verändert beim Neustart des Programms</translation>
    </message>
    <message>
        <source>Start with hidden window</source>
        <translation type="obsolete">Start mit minimiertem Fenster</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="obsolete">Standard</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../settingsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished">Einstellungen</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="27"/>
        <source>Record settings (ffmpeg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="40"/>
        <source>Record settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="52"/>
        <source>Frames pr. sec</source>
        <translation type="unfinished">Bilder pro Sek</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="59"/>
        <source>Changes the framerate in the recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="66"/>
        <source>Video codec</source>
        <translation type="unfinished">Video-Codec</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="73"/>
        <source>Changes the video codec used in the recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="80"/>
        <source>Audio codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="87"/>
        <source>Changes the audio codec used in the recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="94"/>
        <source>Audiochannels</source>
        <translation type="unfinished">Audio-Kanal</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="101"/>
        <source>Changes the number of audiochannels used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="108"/>
        <source>Microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="122"/>
        <source>Basename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="131"/>
        <source>Choose a basename.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="138"/>
        <source>Use the time and date as the basename.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="141"/>
        <source>Time/Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="150"/>
        <source>Default path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="159"/>
        <source>Choose where to save your recordings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="169"/>
        <source>Change the default path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="172"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="181"/>
        <source>Default format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="188"/>
        <source>Choose which format the recordings should be saved with. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="197"/>
        <source>Select a microphone input device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="204"/>
        <source>Mute the microphone. (No audio will be recorded)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="207"/>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="221"/>
        <source>NOTE: Some changes might first apply after a restart of this program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="250"/>
        <source>Save or decline changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="263"/>
        <source>Restores the settings to the defaults. Please note, these can not be undone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="266"/>
        <source>Restore to default. PLEASE NOTE: CAN NOT BE UNDONE!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="269"/>
        <source>Restore to default</source>
        <translation type="unfinished">Standart wiederherstellen</translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="178"/>
        <source>Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>runTerminal</name>
    <message>
        <location filename="../runterminal.cpp" line="59"/>
        <source>Done recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runterminal.cpp" line="63"/>
        <source>Recording failed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
