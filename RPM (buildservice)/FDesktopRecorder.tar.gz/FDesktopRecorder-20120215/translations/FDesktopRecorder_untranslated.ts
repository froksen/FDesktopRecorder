<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AboutProg</name>
    <message>
        <location filename="../aboutprog.ui" line="14"/>
        <source>About kTffmpeqQt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="34"/>
        <source>About FDesktopRecorder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="48"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="63"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2 - &lt;a href=&quot;http://www.gnu.org/licenses/gpl-2.0.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/gpl-2.0.html&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nickname: Froksen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Navn: Ole Holm Frandsen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Based on:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A ffmpeq script by Peter Lybeth from the danish GNU/Linux show &amp;quot;Kanal Tux&amp;quot;: &lt;a href=&quot;http://www.kanaltux.dk&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.kanaltux.dk&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="82"/>
        <source>Translations</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../aboutprog.ui" line="88"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;FDesktopRecorder have been translated into some languages. If you want to translate it into your language you can contact me on opendesktop.org by sending me a message.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Translated by&lt;/span&gt;:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Danish - Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;German - Chris &amp;quot;&lt;span style=&quot; font-family:&apos;arial,sans-serif&apos;; color:#222222; background-color:#ffffff;&quot;&gt;saftsocken&amp;quot; Räss&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="107"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="20"/>
        <source>FDesktopRecorder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <source>When the recording starts, it will record your entire desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Records your entire desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="42"/>
        <source>Entire screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="55"/>
        <source>When you start the recording, you will have to choose the window that you want to record</source>
        <extracomment>dsfdsfds</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <source>Record a single window or screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="61"/>
        <source>Single Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="71"/>
        <source>Start a recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="74"/>
        <source>Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="94"/>
        <source>Stop the recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="97"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="104"/>
        <source>If checked, it will record no audio from the microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="107"/>
        <source>Mute the microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="110"/>
        <source>Mute microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="176"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="179"/>
        <source>Shows information about this program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>About FDesktopRecorder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="187"/>
        <location filename="../mainwindow.ui" line="193"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="190"/>
        <source>Let you change an amount of different settings like recording framerate etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="198"/>
        <source>Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Shows a console where you can see the output. Usefull if recording fails.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="204"/>
        <source>Show/Hide console output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Open recording directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <location filename="../mainwindow.ui" line="215"/>
        <source>Open directory containing your recordings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="35"/>
        <source>Start recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="37"/>
        <source>Minimize and start record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="230"/>
        <location filename="../mainwindow.cpp" line="432"/>
        <location filename="../mainwindow.cpp" line="444"/>
        <source>Recording started</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="241"/>
        <source>Please wait while saving the recording. Might take some time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="278"/>
        <source>Successfully finished recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="285"/>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>Latest Recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="292"/>
        <source>Failed to recording!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="295"/>
        <source>Failed to start recording!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="296"/>
        <source>Press &apos;show details&apos; to see console ouput.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="328"/>
        <source>&amp;Show/Hide window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="331"/>
        <source>&amp;Stop recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="334"/>
        <source>&amp;Latest recording: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="341"/>
        <source>&amp;Quit program</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../settingsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="27"/>
        <source>Record settings (ffmpeg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="40"/>
        <source>Record settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="62"/>
        <source>Basic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="70"/>
        <source>Frames pr. sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="77"/>
        <source>Changes the framerate in the recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="84"/>
        <source>Video codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="91"/>
        <source>Changes the video codec used in the recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="98"/>
        <source>Audio codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="105"/>
        <source>Changes the audio codec used in the recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="112"/>
        <source>Audiochannels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="119"/>
        <source>Changes the number of audiochannels used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="126"/>
        <source>Microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="140"/>
        <source>Basename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="149"/>
        <source>Choose a basename.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="156"/>
        <source>Use the time and date as the basename.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="159"/>
        <source>Time/Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="168"/>
        <source>Default path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="177"/>
        <source>Choose where to save your recordings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="187"/>
        <source>Change the default path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="190"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="199"/>
        <source>Default format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="206"/>
        <source>Choose which format the recordings should be saved with. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="215"/>
        <source>Select a microphone input device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="222"/>
        <source>Mute the microphone. (No audio will be recorded)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="225"/>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="240"/>
        <source>Audio source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="284"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="292"/>
        <source>-apre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="302"/>
        <location filename="../settingsdialog.ui" line="323"/>
        <source>Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="313"/>
        <source>-vpre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="349"/>
        <location filename="../settingsdialog.ui" line="420"/>
        <source>NOTE: Some changes might first apply after a restart of this program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="357"/>
        <source>Application Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="370"/>
        <source>Application settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="382"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="433"/>
        <source>Save or decline changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="446"/>
        <source>Restores the settings to the defaults. Please note, these can not be undone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="449"/>
        <source>Restore to default. PLEASE NOTE: CAN NOT BE UNDONE!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="452"/>
        <source>Restore to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="101"/>
        <source>Restore everything to default?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="102"/>
        <source>If you press Yes everything will be restored to default. 

 Be aware that this can NOT be undone.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="231"/>
        <source>Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsManager</name>
    <message>
        <location filename="../settingsmanager.cpp" line="25"/>
        <location filename="../settingsmanager.cpp" line="63"/>
        <source>recording</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
