<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="da_DK">
<context>
    <name>AboutProg</name>
    <message>
        <location filename="../aboutprog.ui" line="14"/>
        <source>About kTffmpeqQt</source>
        <translation>Om kTffmpeqQt</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="48"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="63"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licence: &lt;/span&gt;GPLv2 - &lt;a href=&quot;http://www.gnu.org/licenses/gpl-2.0.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/gpl-2.0.html&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Created by:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nickname: Froksen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Navn: Ole Holm Frandsen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Based on:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A ffmpeq script by Peter Lybeth from the danish GNU/Linux show &amp;quot;Kanal Tux&amp;quot;: &lt;a href=&quot;http://www.kanaltux.dk&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.kanaltux.dk&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Licens: &lt;/span&gt;GPLv2 - &lt;a href=&quot;http://www.gnu.org/licenses/gpl-2.0.html&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/gpl-2.0.html&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-weight:600;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lavet af:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Nickname: Froksen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Navn: Ole Holm Frandsen&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Baseret på:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Et ffmpeq script af Peter Lybeth fra det danske GNU/Linux show &amp;quot;Kanal Tux&amp;quot;: &lt;a href=&quot;http://www.kanaltux.dk&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.kanaltux.dk&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="82"/>
        <source>Translations</source>
        <translation>Oversættelser</translation>
    </message>
    <message utf8="true">
        <location filename="../aboutprog.ui" line="88"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;FDesktopRecorder have been translated into some languages. If you want to translate it into your language you can contact me on opendesktop.org by sending me a message.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Translated by&lt;/span&gt;:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Danish - Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;German - Chris &amp;quot;&lt;span style=&quot; font-family:&apos;arial,sans-serif&apos;; color:#222222; background-color:#ffffff;&quot;&gt;saftsocken&amp;quot; Räss&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;FDesktopRecorder er oversat til nogle sprog. Hvis du vil oversætte det til dit sprog can du kontakte mig på opendesktop.org hvor du kan skrive mig en besked.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Oversat af&lt;/span&gt;:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Danish - Ole &amp;quot;Froksen&amp;quot; Holm Frandsen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;German - Chris &amp;quot;&lt;span style=&quot; font-family:&apos;arial,sans-serif&apos;; color:#222222; background-color:#ffffff;&quot;&gt;saftsocken&amp;quot; Räss&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="107"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../aboutprog.ui" line="34"/>
        <source>About FDesktopRecorder</source>
        <translation>Om FDesktopRecorder</translation>
    </message>
</context>
<context>
    <name>ApplicationSettings</name>
    <message>
        <source>Startup Behavior</source>
        <translation type="obsolete">Opstartshåndtering</translation>
    </message>
    <message>
        <source>If checked the application will start with a hidden main window.</source>
        <translation type="obsolete">Hvis afkrydset vil programmet starte med skjult hoved vindue.</translation>
    </message>
    <message>
        <source>Start with hidden window</source>
        <translation type="obsolete">Start med skjult hovedvindue</translation>
    </message>
</context>
<context>
    <name>ConfigurationFile</name>
    <message>
        <source>recording</source>
        <translation type="obsolete">optagelse</translation>
    </message>
</context>
<context>
    <name>DialogTerminalOutput</name>
    <message>
        <source>Dialog</source>
        <translation type="obsolete">Dialog</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="obsolete">Luk</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="20"/>
        <source>FDesktopRecorder</source>
        <translation>FDesktopRecorder</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="36"/>
        <source>When the recording starts, it will record your entire desktop</source>
        <translation>Når optagelsen starter, vil den optage hele dit skrivebord</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Records your entire desktop</source>
        <translation>Optage hele dit skrevebord</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="55"/>
        <source>When you start the recording, you will have to choose the window that you want to record</source>
        <extracomment>dsfdsfds</extracomment>
        <translation>Når du starter optagelsen, skal du vælge hvilket vindue du vil optage</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="58"/>
        <source>Record a single window or screen.</source>
        <translation>Optage et enkelt vindue eller skærm.</translation>
    </message>
    <message>
        <source>Single window</source>
        <translation type="obsolete">Enkelt vindue</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="71"/>
        <source>Start a recording</source>
        <translation>Start en optagelse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="74"/>
        <source>Record</source>
        <translation>Optag</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="97"/>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="104"/>
        <source>If checked, it will record no audio from the microphone</source>
        <translation>Hvis afkrydset, vil der ikke blive optaget noget lyd fra mikrofonen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="107"/>
        <source>Mute the microphone</source>
        <translation>Sluk mikrofonen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="110"/>
        <source>Mute microphone</source>
        <translation>Sluk mikofon</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="179"/>
        <source>Shows information about this program</source>
        <translation>Viser dit informationer om dette program</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="190"/>
        <source>Let you change an amount of different settings like recording framerate etc.</source>
        <translation>Lader dig ændre en række indstillinger, som billeder i sekundet osv.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Shows a console where you can see the output. Usefull if recording fails.</source>
        <translation>Viser en konsole hvor du kan se et output. Kan være brugbart hvis en optagelse fejler.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="204"/>
        <source>Show/Hide console output</source>
        <translation>Vis/Gem konsol output</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Open recording directory</source>
        <translation>Åben optagemappe
</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <location filename="../mainwindow.ui" line="215"/>
        <source>Open directory containing your recordings</source>
        <translation>Åben mappen der indeholder dine optagelser</translation>
    </message>
    <message>
        <source>Show console output</source>
        <translation type="obsolete">Vis konsol output</translation>
    </message>
    <message>
        <source>Show Terminal output</source>
        <translation type="obsolete">Vis terminal output</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="198"/>
        <source>Console</source>
        <translation>Konsol</translation>
    </message>
    <message>
        <source>Record screen</source>
        <translation type="obsolete">Optag skærmen</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation type="obsolete">Gennemse</translation>
    </message>
    <message>
        <source>Filename</source>
        <translation type="obsolete">Filnavn</translation>
    </message>
    <message>
        <source>Specify the location where you want to save the recorded file</source>
        <translation type="obsolete">Vælg placering hvor du vil gemme den optagede fil</translation>
    </message>
    <message>
        <source>Recording</source>
        <translation type="obsolete">Optager</translation>
    </message>
    <message>
        <source>Lets you choose where the recorded file should be saved</source>
        <translation type="obsolete">Lader dig vælge hvor du vil gemme den optagede fil</translation>
    </message>
    <message>
        <source>File exists. If you continue it will be overwritten</source>
        <translation type="obsolete">Filen existerer. Hvis du fortsætter vil den blive overskrevet</translation>
    </message>
    <message>
        <source>Fileformat</source>
        <translation type="obsolete">Filformat</translation>
    </message>
    <message>
        <source>Choose the fileformat for the recording</source>
        <translation type="obsolete">Vælg hvilket filformat optagelsen skal gemmes i</translation>
    </message>
    <message>
        <source>Recording area</source>
        <translation type="obsolete">Optage område</translation>
    </message>
    <message>
        <source>Sets the recording area to a single window</source>
        <translation type="obsolete">Sætter optage området til et enkelt vindue</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="61"/>
        <source>Single Window</source>
        <translation>Enkelt vindue</translation>
    </message>
    <message>
        <source>Sets the recording area to a custom size</source>
        <translation type="obsolete">Sætter optage området til et selvvalgt størrelse</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation type="obsolete">Selvvalgt</translation>
    </message>
    <message>
        <source>Sets the recording area to the entire screen</source>
        <translation type="obsolete">Sætter optage området til hele skærmen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="42"/>
        <source>Entire screen</source>
        <translation>Hele skærmen</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">Bredde</translation>
    </message>
    <message>
        <source>Set width</source>
        <translation type="obsolete">Bestem bredden</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="obsolete">Højde</translation>
    </message>
    <message>
        <source>Set height</source>
        <translation type="obsolete">Bestem højden</translation>
    </message>
    <message>
        <source>Microfone</source>
        <translation type="obsolete">Microfon</translation>
    </message>
    <message>
        <source>Choose an audioinput from which the sound should be recorded</source>
        <translation type="obsolete">Vælg det lydinput hvor lyden skal optages fra</translation>
    </message>
    <message>
        <source>If checked no audio will be recorded</source>
        <translation type="obsolete">Hvis afkrydset vil der ikke blive optaget nogen lyd</translation>
    </message>
    <message>
        <source>Record no sound</source>
        <translation type="obsolete">Optag ingen lyd</translation>
    </message>
    <message>
        <source>Delay start a number of seconds</source>
        <translation type="obsolete">Udskyd starten et antal sekunder</translation>
    </message>
    <message>
        <source>Delay start </source>
        <translation type="obsolete">Udskud start</translation>
    </message>
    <message>
        <source>Delay the start by a number of seconds...</source>
        <translation type="obsolete">Udskyd starten med et antal sekunder...</translation>
    </message>
    <message>
        <source>Start the recording</source>
        <translation type="obsolete">Start optagelsen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="35"/>
        <source>Start recording</source>
        <translation>Start optagelse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="94"/>
        <source>Stop the recording</source>
        <translation>Stop optagelsen</translation>
    </message>
    <message>
        <source>Stop recording</source>
        <translation type="obsolete">Stop optagelse</translation>
    </message>
    <message>
        <source>Quits the program</source>
        <translation type="obsolete">Afslutter programmet</translation>
    </message>
    <message>
        <source>Quit Program</source>
        <translation type="obsolete">Afslut program</translation>
    </message>
    <message>
        <source>The main window will be minimized to systemtray</source>
        <translation type="obsolete">Hovedvinduet vil blive minimeret til statusområdet</translation>
    </message>
    <message>
        <source>Minimize to tray</source>
        <translation type="obsolete">Minimér til statusområde</translation>
    </message>
    <message>
        <source>Shows the terminalouput if the ffmpeq script</source>
        <translation type="obsolete">Viser terminaloutputtet fra ffmpeq scriptet</translation>
    </message>
    <message>
        <source>Show terminal output</source>
        <translation type="obsolete">Vis terminal output</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="176"/>
        <source>About</source>
        <translation>Om</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="obsolete">Rediger</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="182"/>
        <source>About FDesktopRecorder</source>
        <translation>Om FDesktopRecorder</translation>
    </message>
    <message>
        <source>Application Settings</source>
        <translation type="obsolete">Program indstillinger</translation>
    </message>
    <message>
        <source>About kTffmpeqQt</source>
        <translation type="obsolete">Om kTffmpeqQt</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="obsolete">Om Qt</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="187"/>
        <location filename="../mainwindow.ui" line="193"/>
        <source>Settings</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="37"/>
        <source>Minimize and start record</source>
        <translation>Minimér og start optagelse</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="230"/>
        <location filename="../mainwindow.cpp" line="432"/>
        <location filename="../mainwindow.cpp" line="444"/>
        <source>Recording started</source>
        <translation>Optagelse startet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="241"/>
        <source>Please wait while saving the recording. Might take some time.</source>
        <translation>Vent venligst mens optagelsen bliver gemt. Dette kan tage lidt tid.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="278"/>
        <source>Successfully finished recording</source>
        <translation>Afsluttede optagelsen korrekt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="285"/>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>Latest Recording</source>
        <translation>Seneste optagelse</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="292"/>
        <source>Failed to recording!</source>
        <translation>Optagelse fejlede!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="295"/>
        <source>Failed to start recording!</source>
        <translation>Optagelse fejlede!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="296"/>
        <source>Press &apos;show details&apos; to see console ouput.</source>
        <translation>Tryk på &quot;show details&quot; for at se konsol ouput.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="328"/>
        <source>&amp;Show/Hide window</source>
        <translation>&amp;Vis/Gem vindue</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="331"/>
        <source>&amp;Stop recording</source>
        <translation>&amp;Stop optagelse</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="334"/>
        <source>&amp;Latest recording: </source>
        <translation>&amp;Seneste optagelse:</translation>
    </message>
    <message>
        <source>Latest recording: </source>
        <translation type="obsolete">Seneste optagelse:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="341"/>
        <source>&amp;Quit program</source>
        <translation>&amp;Afslut program</translation>
    </message>
    <message>
        <source>recording</source>
        <translation type="obsolete">optagelse</translation>
    </message>
    <message>
        <source>Start recording and minimize</source>
        <translation type="obsolete">Start optagelse og minimér</translation>
    </message>
    <message>
        <source>Script saved: </source>
        <translation type="obsolete">Script er gemt: </translation>
    </message>
    <message>
        <source>Sure that you want to start a recording in </source>
        <translation type="obsolete">Sikker på at du vil starte en optagelse om </translation>
    </message>
    <message>
        <source>Sure that you want to start a recording?</source>
        <translation type="obsolete">Sikker på at du vil starte en optagelse?</translation>
    </message>
    <message>
        <source>Press &apos;show details&apos; for information about the script. USE AT OWN RISK</source>
        <translation type="obsolete">Tryk på &apos;Vis detaljer&apos; for mere information om scriptet. Brug under eget ansvar</translation>
    </message>
    <message>
        <source>Recording starts in </source>
        <translation type="obsolete">Optagelse starter om </translation>
    </message>
    <message>
        <source>Recording not yet startet but when the icon changes, the recording starts.</source>
        <translation type="obsolete">Optagelsen er endnu ikk startet. Men når ikonet ændres, så starter optagelsen.</translation>
    </message>
    <message>
        <source>No recording started</source>
        <translation type="obsolete">Ingen optagelse startet</translation>
    </message>
    <message>
        <source>The program did not start any recording</source>
        <translation type="obsolete">Programmet startede ingen optagelse</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Gem</translation>
    </message>
    <message>
        <source>Movies (*.mkv *.avi)</source>
        <oldsource>Film (*.mkv *.avi)</oldsource>
        <translation type="obsolete">Film (*.mkv *.avi)</translation>
    </message>
    <message>
        <source>Movies (*.mkv *.avi *.ogg *.mpeg *.flv *.wmv *.mov)</source>
        <translation type="obsolete">Film (*.mkv *.avi *.ogg *.mpeg *.flv *.wmv *.mov)</translation>
    </message>
    <message>
        <source>Window hidden</source>
        <translation type="obsolete">Vindue gemt</translation>
    </message>
    <message>
        <source>The programs continues to run in systemtray. Right-click the icon for more options</source>
        <translation type="obsolete">Programmet fortsætter i statusområdet. Højreklik for at få flere informationer</translation>
    </message>
    <message>
        <source>INFORMATION: Delayed start stoppet!</source>
        <translation type="obsolete">INFORMATION: Udskudt start stoppet!</translation>
    </message>
    <message>
        <source>Delayed start stoppet!</source>
        <translation type="obsolete">Udskudt start stoppet!</translation>
    </message>
    <message>
        <source>The delayed start was stopped and therefore no recording will start</source>
        <translation type="obsolete">Den udskudte start blev stoppet og derfor vil der ikke blive startet nogen optagelse</translation>
    </message>
    <message>
        <source>Error: Recording failed!</source>
        <translation type="obsolete">Fejl: Optagelse fejlede!</translation>
    </message>
    <message>
        <source>Press &apos;show terminal output&apos; for details</source>
        <translation type="obsolete">Tryk på &apos;vis terminal output&apos; for detailjer</translation>
    </message>
    <message>
        <source>INFORMATION: Recording stopped</source>
        <translation type="obsolete">INFORMATION: Optagelse stoppet</translation>
    </message>
    <message>
        <source>Recording finished</source>
        <translation type="obsolete">Færdig med at optage</translation>
    </message>
    <message>
        <source>The program finished recording</source>
        <translation type="obsolete">Programmet er færdig med at optage</translation>
    </message>
    <message>
        <source>Open Containing Folder</source>
        <translation type="obsolete">Vis i mappen</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Indstillinger</translation>
    </message>
    <message>
        <source>Record Settings (ffmpeg)</source>
        <translation type="obsolete">Optage indstillinger (ffmpeg)</translation>
    </message>
    <message>
        <source>Record Settings</source>
        <translation type="obsolete">Optage indstillinger</translation>
    </message>
    <message>
        <source>Frames pr. sec</source>
        <translation type="obsolete">Billeder i sekundet</translation>
    </message>
    <message>
        <source>Video codec</source>
        <translation type="obsolete">Video codec</translation>
    </message>
    <message>
        <source>Auto detect</source>
        <translation type="obsolete">Automatisk</translation>
    </message>
    <message>
        <source>Sound codec</source>
        <translation type="obsolete">Lyd codec</translation>
    </message>
    <message>
        <source>Audiochannels</source>
        <translation type="obsolete">Lyd kanaler</translation>
    </message>
    <message>
        <source>Restore to default</source>
        <translation type="obsolete">Gendan til standard</translation>
    </message>
    <message>
        <source>Startup Behavior</source>
        <translation type="obsolete">Opstartshåndtering</translation>
    </message>
    <message>
        <source>If checked the application will start with a hidden main window.</source>
        <translation type="obsolete">Hvis afkrydset vil programmet starte med skjult hoved vindue.</translation>
    </message>
    <message>
        <source>Start with hidden window *</source>
        <translation type="obsolete">Start med skjult hovedvindue</translation>
    </message>
    <message>
        <source>recording</source>
        <translation type="obsolete">optagelse</translation>
    </message>
    <message>
        <source>Default filename *</source>
        <translation type="obsolete">Standard filnavn *</translation>
    </message>
    <message>
        <source>Default fileformat *</source>
        <translation type="obsolete">Standard filformat *</translation>
    </message>
    <message>
        <source>Default record device *</source>
        <translation type="obsolete">Standard optage enhed</translation>
    </message>
    <message>
        <source>* Will first take effect after a restart of this program</source>
        <translation type="obsolete">* Vil først have en effekt efter en genstart af dette program</translation>
    </message>
    <message>
        <source>Start with hidden window</source>
        <translation type="obsolete">Start med skjult hovedvindue</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="obsolete">Standard</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../settingsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="27"/>
        <source>Record settings (ffmpeg)</source>
        <translation>Optage indstillinger (ffmpeg)</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="40"/>
        <source>Record settings</source>
        <translation>Optage indstillinger</translation>
    </message>
    <message>
        <source>Frames pr. second</source>
        <translation type="obsolete">Billeder i sekundet</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="62"/>
        <source>Basic</source>
        <translation>Basal</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="70"/>
        <source>Frames pr. sec</source>
        <translation>Billeder i sekundet</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="77"/>
        <source>Changes the framerate in the recording</source>
        <translation>Ændre billedraten i optagelsen</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="84"/>
        <source>Video codec</source>
        <translation>Video codec</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="91"/>
        <source>Changes the video codec used in the recording</source>
        <translation>Ændre det video codec der bliver brugt i optagelsen</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="98"/>
        <source>Audio codec</source>
        <translation>Lyd codec</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="105"/>
        <source>Changes the audio codec used in the recording</source>
        <translation>Ændre det lyd codec der bliver brugt i optagelsen</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="112"/>
        <source>Audiochannels</source>
        <translation>Lyd kanaler</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="119"/>
        <source>Changes the number of audiochannels used</source>
        <translation>Ændre antallet af lydkanaler der bliver brugt</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="126"/>
        <source>Microphone</source>
        <translation>Microfon</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="140"/>
        <source>Basename</source>
        <translation>Grundnavn</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="149"/>
        <source>Choose a basename.</source>
        <translation>Vælg et grundnavn.</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="156"/>
        <source>Use the time and date as the basename.</source>
        <translation>Brug tid og dato som grundnavn.</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="159"/>
        <source>Time/Date</source>
        <translation>Tid/dato</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="168"/>
        <source>Default path</source>
        <translation>Standard sti</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="177"/>
        <source>Choose where to save your recordings</source>
        <translation>Vælg hvor dine optagelser skal gemmes</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="187"/>
        <source>Change the default path.</source>
        <translation>Ændre standard stien.</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="190"/>
        <source>Change</source>
        <translation>Ændre</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="199"/>
        <source>Default format</source>
        <translation>Standard format</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="206"/>
        <source>Choose which format the recordings should be saved with. </source>
        <translation>Vælg hvilket format optagelserne skal gemmes i.</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="215"/>
        <source>Select a microphone input device</source>
        <translation>Vælg en mikrofon inputenhed</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="222"/>
        <source>Mute the microphone. (No audio will be recorded)</source>
        <translation>Sluk mikrofonen (Ingen lyd vil blive optaget)</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="225"/>
        <source>Mute</source>
        <translation>Sluk</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="240"/>
        <source>Audio source</source>
        <translation>Lydkilde</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="284"/>
        <source>Advanced</source>
        <translation>Advanceret</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="292"/>
        <source>-apre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="302"/>
        <location filename="../settingsdialog.ui" line="323"/>
        <source>Use</source>
        <translation>Brug</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="313"/>
        <source>-vpre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="349"/>
        <location filename="../settingsdialog.ui" line="420"/>
        <source>NOTE: Some changes might first apply after a restart of this program</source>
        <translation>NOTE: Nogle ændringer har måske først virkning efter en 
genstart af programmet</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="357"/>
        <source>Application Settings</source>
        <translation>Program indstillinger</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="370"/>
        <source>Application settings</source>
        <translation>Program indstillinger</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="382"/>
        <source>Language</source>
        <translation>Sprog</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="433"/>
        <source>Save or decline changes</source>
        <translation>Gem eller afvis ændringerne</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="446"/>
        <source>Restores the settings to the defaults. Please note, these can not be undone!</source>
        <translation>Gendanner standard indstillingerne. Vær OBS på at dette ikke kan fortrydes!</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="449"/>
        <source>Restore to default. PLEASE NOTE: CAN NOT BE UNDONE!</source>
        <translation>Gendan til standard. OBS: Kan ikke fortrydes!</translation>
    </message>
    <message>
        <location filename="../settingsdialog.ui" line="452"/>
        <source>Restore to default</source>
        <translation>Gendan til standard</translation>
    </message>
    <message>
        <source>recording</source>
        <translation type="obsolete">optagelse</translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="101"/>
        <source>Restore everything to default?</source>
        <translation>Gendan alt tilbage til standard?</translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="102"/>
        <source>If you press Yes everything will be restored to default. 

 Be aware that this can NOT be undone.</source>
        <translation>Hvis du trykker på Ja vil alt blive gendannet til standard.

 Vær opmærksom på at dette ikke kan fortrydes.</translation>
    </message>
    <message>
        <location filename="../settingsdialog.cpp" line="231"/>
        <source>Open Directory</source>
        <translation>Åben mappe</translation>
    </message>
</context>
<context>
    <name>SettingsManager</name>
    <message>
        <location filename="../settingsmanager.cpp" line="25"/>
        <location filename="../settingsmanager.cpp" line="63"/>
        <source>recording</source>
        <translation>optagelse</translation>
    </message>
</context>
<context>
    <name>runTerminal</name>
    <message>
        <source>Done recording</source>
        <translation type="obsolete">Færdig med at optage</translation>
    </message>
    <message>
        <source>Recording failed!</source>
        <translation type="obsolete">Optagelsen fejlede!</translation>
    </message>
</context>
</TS>
